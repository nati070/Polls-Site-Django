from setuptools import setup
from setuptools import setup

setup()